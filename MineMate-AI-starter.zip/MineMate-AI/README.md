# MineMate-AI

Fabric starter project for **Minecraft Java 1.21.11**.

## Build
The GitHub Actions workflow builds on each push. Open the repository's Actions tab, select the latest successful **Build MineMate-AI** run, and download the `MineMate-AI-1.21.11` artifact.

## Development status
- [x] Fabric project scaffold
- [x] GitHub Actions build workflow
- [x] `/minemate status` test command
- [ ] Visible companion-player bot
- [ ] Follow and stop behavior
- [ ] Mining and block placement behaviors

This is a starter build, not the completed autonomous companion. Features will be added and tested incrementally.
